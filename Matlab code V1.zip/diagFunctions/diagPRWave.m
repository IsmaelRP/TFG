function msg = diagPRWave(ecg)

    %% Calcula las dimensiones del intervalo PR para determinar duración correcta
    %   Problema de bloqueo de la conducción eléctrica: > 5 cuadritos ancho/alto
    %   Problema de bloqueo de la conducción eléctrica: < 3 cuadritos ancho/alto


    moda = mode(ecg);

    [~, posR, anchuraR] = findpeaks(ecg, 'MinPeakProminence', 20, 'MinPeakHeight', 60, 'MinPeakDistance', 100);

    % Para visualizar ************************************************************************************
    findpeaks(ecg, 'MinPeakProminence', 20, 'MinPeakHeight', 60, 'MinPeakDistance', 20);
    hold on;

    for i=1:length(posR)
        if i < length(posR)
            limpiarHasta = round((posR(i+1) - posR(i)) / 2);
        end

        ecg( posR(i) - round(anchuraR(i)) + 3 : posR(i) + limpiarHasta ) = moda - 5;
        plot(ecg, 'r');

    end
    
    [~, posP, anchuraP] = findpeaks(ecg, 'MinPeakDistance', 100, 'MaxPeakWidth', 40, 'MinPeakWidth', 10);

    % Para visualizar ****************************************
    findpeaks(ecg, 'MinPeakDistance', 100, 'MaxPeakWidth', 40, 'MinPeakWidth', 10);
    hold off;

    inicioP = posP - (anchuraP / 2);
    inicioR = posR - (anchuraR / 2);

    if length(anchuraP) > length(anchuraR)
        msg = "Bloqueo AV de 2º grado Mobitz tipo 1, se omiten complejos QRS";
    else
        anchuraPR = (inicioR - inicioP) / 10 + 0.5;
        cont = 0;
        for i=1:length(anchuraPR)-1
            if anchuraPR(i+1)+0.5 > anchuraPR(i)
                cont = cont + 1;
            end
        end
        if cont > 3
            msg = "Bloqueo AV de 2º grado Mobitz tipo 1, se prolongan los intervalos PR progresivamente";
        end
    end

    if ~exist('msg', 'var')
        if mean(anchuraPR > 5) > 0.70 || mean(anchuraPR < 3) > 0.70
            msg = "Bloqueo AV de 1º grado debido a intervalo PR anormal";
        else
            msg = "Intervalo PR normal (no hay bloqueo de conducción eléctrica)";
        end
    end
    
end

