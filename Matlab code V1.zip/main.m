close all, clear all, clc;
dbstop if error

img = imread('../bloqueo21.jpg');
%img = imread('../mobitz.png');


% BORRAR
%espaciado  = get_espaciado(im);
img = imcrop(img);
%subplot(2, 1, 1);
%imshow(img);
% BORRAR

%msg = getDiagnoseMsg(img)

vector = getSignal(img);
%diagPulseDiff(vector)  % Método 5
%diagPWave(vector)      % Método 1
%diagQRSWave(vector)    % Método 3
diagPRWave(vector)     % Método 2
%diagQTWave(vector)     % Método 4




